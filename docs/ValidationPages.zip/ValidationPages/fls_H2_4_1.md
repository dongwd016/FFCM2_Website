---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_H2_4_1
temp: 295.0
pres: 1.0
phi: 0.85
composition: 11.97% H2-7.04% O2-80.99% HE
shortname: BCD2010
datatype: Laminar flame speed
definition: FFCM1FLS
exp_nominal: 95.3
exp_uq: 9.53
trial_nominal: 91.23
trial_uq: 3.89
opt_nominal: 89.13
opt_uq: 1.33
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_H2_4.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_H2_4_1.png
reference: BCD2010 - Burke, Michael P., Chaos, M., Dryer, F. L., & Ju, Y. (2010). Negative pressure dependence of mass burning rates of H2/CO/O2/diluent flames at low flame temperatures. Combustion and Flame, 157, 618–631.
uq_unit: cm/s
---