---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_H2_1_5
temp: 298.0
pres: 1.0
phi: 1.0
composition: 29.59% H2-14.79% O2-55.62% N2
shortname: TZL2000, AHF1997, VEL1994, THJ2008, HHH2009, BLL2007, LDP2003, T1991, HZZ2006
datatype: Laminar flame speed
definition: FFCM1FLS
exp_nominal: 211.17
exp_uq: 10.99
trial_nominal: 211.16
trial_uq: 8.22
opt_nominal: 210.42
opt_uq: 3.1
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_H2_1.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_H2_1_5.png
reference: TZL2000 - Tse, S. D., Zhu, D. L., & Law, C. K. (2000). Morphology and burning rates of expanding spherical flames in H2/O2/inert mixtures up to 60 atmospheres. Proceedings of the Combustion Institute, 28, 1793–1800.<br>AHF1997 - Aung, K. T., Hassan, M. I., & Faeth, G. M. (1997). Flame stretch interactions of laminar premixed hydrogen/air flames at normal temperature and pressure. Combustion and Flame, 109, 1–24.<br>VEL1994 - Vagelopoulos, C. M., Egolfopoulos, F. N., & Law, C. K. (1994). Further considerations on the determination of laminar flame speeds with the counterflow twin-flame technique. Symposium (International) on Combustion, 25, 1341–1347.<br>THJ2008 - Tang, C., Huang, Z., Jin, C., He, J., Wang, J., Wang, X., & Miao, H. (2008). Laminar burning velocities and combustion characteristics of propane--hydrogen--air premixed flames. International Journal of Hydrogen Energy, 33, 4906–4914.<br>HHH2009 - Hu, E., Huang, Z., He, J., Jin, C., & Zheng, J. (2009). Experimental and numerical study on laminar burning characteristics of premixed methane--hydrogen--air flames. International Journal of Hydrogen Energy, 34, 4876–4888.<br>BLL2007 - Bradley, D., Lawes, M., Liu, K., Verhelst, S., & Woolley, R. (2007). Laminar burning velocities of lean hydrogen--air mixtures at pressures up to 1.0 MPa. Combustion and Flame, 149, 162–172.<br>LDP2003 - Lamoureux, N., Djeba\\"ili-Chaumeix, N., & Paillard, C. E. (2003). Laminar flame velocity determination for H2--air--He--CO2 mixtures using the spherical bomb method. Experimental Thermal and Fluid Science, 27, 385–393.<br>T1991 - Taylor SC. (1991). Burning velocity and the influence of flame stretch.<br>HZZ2006 - Huang, Z., Zhang, Y., Zeng, K., Liu, B., Wang, Q., & Jiang, D. (2006). Measurements of laminar burning velocities for natural gas--hydrogen--air mixtures. Combustion and Flame, 146, 302–311.
uq_unit: cm/s
---