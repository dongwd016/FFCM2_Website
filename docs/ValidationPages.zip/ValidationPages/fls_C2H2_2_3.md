---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C2H2_2_3
temp: 300.0
pres: 1.0
phi: 0.8
composition: 3.99% C2H2-12.48% O2-83.53% N2
shortname: PVE2013, EZL1990
datatype: Laminar flame speed
definition: CFF
exp_nominal: 29.51
exp_uq: 2.0
trial_nominal: 29.53
trial_uq: 2.07
opt_nominal: 30.52
opt_uq: 0.66
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C2H2_2.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C2H2_2_3.png
reference: PVE2013 - Park, O., Veloo, P. S., & Egolfopoulos, F. N. (2013). Flame studies of C2 hydrocarbons. Proceedings of the Combustion Institute, 34, 711–718.<br>EZL1990 - Egolfopoulos, F. N., Zhu, D. L., & Law, C. K. (1990). Experimental and numerical determination of laminar flame speeds Mixtures of C2-hydrocarbons with oxygen and nitrogen. Symposium (International) on Combustion, 23, 471–478.
uq_unit: cm/s
---