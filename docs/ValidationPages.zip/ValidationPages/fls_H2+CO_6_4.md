---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_H2+CO_6_4
temp: 295.0
pres: 15.0
phi: 1.25
composition: 15.57% H2-15.57% CO-6.23% O2-62.63% AR
shortname: BCD2010
datatype: Laminar flame speed
definition: FFCM1FLS
exp_nominal: 23.6
exp_uq: 2.36
trial_nominal: 21.68
trial_uq: 3.8
opt_nominal: 19.38
opt_uq: 0.63
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_H2+CO_6.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_H2+CO_6_4.png
reference: BCD2010 - Burke, Michael P., Chaos, M., Dryer, F. L., & Ju, Y. (2010). Negative pressure dependence of mass burning rates of H2/CO/O2/diluent flames at low flame temperatures. Combustion and Flame, 157, 618–631.
uq_unit: cm/s
---