---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_H2+CO_6_1
temp: 295.0
pres: 1.0
phi: 1.25
composition: 15.57% H2-15.57% CO-6.23% O2-62.63% AR
shortname: BCD2010
datatype: Laminar flame speed
definition: FFCM1FLS
exp_nominal: 83.0
exp_uq: 8.3
trial_nominal: 82.69
trial_uq: 4.38
opt_nominal: 81.0
opt_uq: 1.27
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_H2+CO_6.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_H2+CO_6_1.png
reference: BCD2010 - Burke, Michael P., Chaos, M., Dryer, F. L., & Ju, Y. (2010). Negative pressure dependence of mass burning rates of H2/CO/O2/diluent flames at low flame temperatures. Combustion and Flame, 157, 618–631.
uq_unit: cm/s
---