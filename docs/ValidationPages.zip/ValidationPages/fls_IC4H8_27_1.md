---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_IC4H8_27_1
temp: 410.76
pres: 15.28
phi: 1.3
composition: 3.03% IC4H8-14.01% O2-4.15% N2-78.81% HE
shortname: MLE2020
datatype: Laminar flame speed
definition: OPF
exp_nominal: 42.9
exp_uq: 2.96
trial_nominal: 41.93
trial_uq: 1.64
opt_nominal: 45.12
opt_uq: 0.67
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_IC4H8_27.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_IC4H8_27_1.png
reference: MLE2020 - Movaghar, A., Lawson, R., & Egolfopoulos, F. N. (2020). Confined spherically expanding flame method for measuring laminar flame speeds Revisiting the assumptions and application to C1C4 hydrocarbon flames. Combustion and Flame, 212, 79–92.
uq_unit: cm/s
---