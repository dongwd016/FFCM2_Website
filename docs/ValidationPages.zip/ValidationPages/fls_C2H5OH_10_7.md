---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C2H5OH_10_7
temp: 328.0
pres: 1.0
phi: 1.3
composition: 8.34% C2H5OH-19.26% O2-72.40% N2
shortname: SAV2014, KMD2011
datatype: Laminar flame speed
definition: HF
exp_nominal: 43.7
exp_uq: 2.0
trial_nominal: 42.62
trial_uq: 1.86
opt_nominal: 42.84
opt_uq: 0.6
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C2H5OH_10.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C2H5OH_10_7.png
reference: SAV2014 - Sileghem, L., Alekseev, V. A., Vancoillie, J., Nilsson, E. J. K., Verhelst, S., & Konnov, A. A. (2014). Laminar burning velocities of primary reference fuels and simple alcohols. Fuel, 115, 32–40.<br>KMD2011 - Konnov, A. A., Meuwissen, R. J., & De Goey, L. P. H. (2011). The temperature dependence of the laminar burning velocity of ethanol flames. Proceedings of the Combustion Institute, 33, 1011–1019.
uq_unit: cm/s
---