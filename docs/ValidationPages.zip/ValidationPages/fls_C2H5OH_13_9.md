---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C2H5OH_13_9
temp: 423.0
pres: 1.0
phi: 1.3
composition: 8.34% C2H5OH-19.26% O2-72.40% N2
shortname: BHS2013
datatype: Laminar flame speed
definition: OPF
exp_nominal: 60.23
exp_uq: 6.02
trial_nominal: 65.48
trial_uq: 2.66
opt_nominal: 65.94
opt_uq: 0.89
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C2H5OH_13.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C2H5OH_13_9.png
reference: BHS2013 - Broustail, G., Halter, F., Seers, P., Moréac, G., & Mouna\\"im-Rousselle, C. (2013). Experimental determination of laminar burning velocity for butanol/iso-octane and ethanol/iso-octane blends for different initial pressures. Fuel, 106, 310–317.
uq_unit: cm/s
---