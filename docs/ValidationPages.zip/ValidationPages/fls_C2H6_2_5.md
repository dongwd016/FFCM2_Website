---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C2H6_2_5
temp: 298.0
pres: 1.0
phi: 0.8
composition: 4.58% C2H6-20.05% O2-75.37% N2
shortname: GBD2016, RSM2015, LDK2011, DLB2011, BD2004, KDD2003, HAK1998, ATI1995, PVE2013, DDK2007, JZZ2005, VE1998
datatype: Laminar flame speed
definition: HF
exp_nominal: 28.71
exp_uq: 2.0
trial_nominal: 33.24
trial_uq: 1.15
opt_nominal: 30.26
opt_uq: 0.35
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C2H6_2.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C2H6_2_5.png
reference: GBD2016 - Goswami, M., Bastiaans, R. J. M., De Goey, L. P. H., & Konnov, A. A. (2016). Experimental and modelling study of the effect of elevated pressure on ethane and propane flames. Fuel, 166, 410–418.<br>RSM2015 - Ravi, S., Sikes, T. G., Morones, A., Keesee, C. L., & Petersen, E. L. (2015). Comparative study on the laminar flame speed enhancement of methane with ethane and ethylene addition. Proceedings of the Combustion Institute, 35, 679–686.<br>LDK2011 - Lowry, W., De Vries, J., Krejci, M., Petersen, E., Serinyel, Z., Metcalfe, W., … Bourque, G. (2011). Laminar flame speed measurements and modeling of pure alkanes and alkane blends at elevated pressures. Journal of Engineering for Gas Turbines and Power, 133.<br>DLB2011 - Dirrenberger, Patricia, Le Gall, H., Bounaceur, R., Herbinet, O., Glaude, P.-A., Konnov, A., & Battin-Leclerc, F. (2011). Measurements of Laminar Flame Velocity for Components of Natural Gas. Energy & Fuels, 25, 3875–3884.<br>BD2004 - Bosschaart, K. J., & De Goey, L. P. H. (2004). The laminar burning velocity of flames propagating in mixtures of hydrocarbons and air measured with the heat flux method. Combustion and Flame, 136, 261–269.<br>KDD2003 - Konnov, Alexander A., Dyakov, I. V., & De Ruyck, J. (2003). Measurement of adiabatic burning velocity in ethane-oxygen-nitrogen and in ethane-oxygen-argon mixtures. Experimental Thermal and Fluid Science, 27, 379–384.<br>HAK1998 - Hassan, M. I., Aung, K. T., Kwon, O. C., & Faeth, G. M. (1998). Properties of laminar premixed hydrocarbon/air flames at various pressures. Journal of Propulsion and Power, 14, 479–488.<br>ATI1995 - Aung, K. T., Tseng, L. K., Ismail, M. A., & Faeth, G. M. (1995). Response to comment by S.C. Taylor and D.B. Smith on \\textquotedblleftlaminar burning velocities and Markstein numbers of hydrocarbon/air flames\\textquotedblright. Combustion and Flame, 102, 526–530.<br>PVE2013 - Park, O., Veloo, P. S., & Egolfopoulos, F. N. (2013). Flame studies of C2 hydrocarbons. Proceedings of the Combustion Institute, 34, 711–718.<br>DDK2007 - Dyakov, I. V., De Ruyck, J., & Konnov, A. A. (2007). Probe sampling measurements and modeling of nitric oxide formation in ethane + air flames. Fuel, 86, 98–105.<br>JZZ2005 - Jomaas, G., Zheng, X. L., Zhu, D. L., & Law, C. K. (2005). Experimental determination of counterflow ignition temperatures and laminar flame speeds of C2--C3 hydrocarbons at atmospheric and elevated pressures. Proceedings of the Combustion Institute, 30, 193–200.<br>VE1998 - Vagelopoulos, Christine M., & Egolfopoulos, F. N. (1998). Direct experimental determination of laminar flame speeds. Symposium (International) on Combustion, 27, 513–519.
uq_unit: cm/s
---