---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C3H8_2_5
temp: 298.0
pres: 1.0
phi: 0.8
composition: 3.25% C3H8-20.33% O2-76.42% N2
shortname: PVS2016, GBD2016, LDK2011, DLB2011, ROB2010, HMS2008, JZZ2005, ZKL2004, LK2004, BD2004, VE1998, HAK1998, ZG1996, MG1994, EZL1990, MK1980
datatype: Laminar flame speed
definition: HF
exp_nominal: 29.35
exp_uq: 2.1
trial_nominal: 29.34
trial_uq: 1.11
opt_nominal: 28.59
opt_uq: 0.42
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C3H8_2.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C3H8_2_5.png
reference: PVS2016 - Park, O., Veloo, P. S., Sheen, D. A., Tao, Y., Egolfopoulos, F. N., & Wang, H. (2016). Chemical kinetic model uncertainty minimization through laminar flame speed measurements. Combustion and Flame, 172, 136–152.<br>GBD2016 - Goswami, M., Bastiaans, R. J. M., De Goey, L. P. H., & Konnov, A. A. (2016). Experimental and modelling study of the effect of elevated pressure on ethane and propane flames. Fuel, 166, 410–418.<br>LDK2011 - Lowry, W., De Vries, J., Krejci, M., Petersen, E., Serinyel, Z., Metcalfe, W., … Bourque, G. (2011). Laminar flame speed measurements and modeling of pure alkanes and alkane blends at elevated pressures. Journal of Engineering for Gas Turbines and Power, 133.<br>DLB2011 - Dirrenberger, Patricia, Le Gall, H., Bounaceur, R., Herbinet, O., Glaude, P.-A., Konnov, A., & Battin-Leclerc, F. (2011). Measurements of Laminar Flame Velocity for Components of Natural Gas. Energy & Fuels, 25, 3875–3884.<br>ROB2010 - Razus, D., Oancea, D., Brinzea, V., Mitu, M., & Movileanu, C. (2010). Experimental and computed burning velocities of propane--air mixtures. Energy Conversion and Management, 51, 2979–2984.<br>HMS2008 - Huzayyin, A. S., Moneib, H. A., Shehatta, M. S., & Attia, A. M. A. (2008). Laminar burning velocity and explosion index of LPG--air and propane--air mixtures. Fuel, 87, 39–57.<br>JZZ2005 - Jomaas, G., Zheng, X. L., Zhu, D. L., & Law, C. K. (2005). Experimental determination of counterflow ignition temperatures and laminar flame speeds of C2--C3 hydrocarbons at atmospheric and elevated pressures. Proceedings of the Combustion Institute, 30, 193–200.<br>ZKL2004 - Zhao, Zhenwei, Kazakov, A., Li, J., & Dryer, F. L. (2004, October). The initial temperature and N2 dilution effect on the laminar flame speed of propane/air. Combustion Science and Technology, 176, 1705–1723.<br>LK2004 - Law, C. K., & Kwon, O. C. (2004). Effects of hydrocarbon substitution on atmospheric hydrogen-air flame propagation. International Journal of Hydrogen Energy, 29, 867–879.<br>BD2004 - Bosschaart, K. J., & De Goey, L. P. H. (2004). The laminar burning velocity of flames propagating in mixtures of hydrocarbons and air measured with the heat flux method. Combustion and Flame, 136, 261–269.<br>VE1998 - Vagelopoulos, Christine M., & Egolfopoulos, F. N. (1998). Direct experimental determination of laminar flame speeds. Symposium (International) on Combustion, 27, 513–519.<br>HAK1998 - Hassan, M. I., Aung, K. T., Kwon, O. C., & Faeth, G. M. (1998). Properties of laminar premixed hydrocarbon/air flames at various pressures. Journal of Propulsion and Power, 14, 479–488.<br>ZG1996 - Zhou, M., & Garner, C. P. (1996). Direct measurements of burning velocity of propane-air using particle image velocimetry. Combustion and Flame, 106, 363–367.<br>MG1994 - Van Maaren, A., & Goey, D. (1994). Stretch and the adiabatic burning velocity of methane and propane-air flames. Combustion Science and Technology, 102, 309–314.<br>EZL1990 - Egolfopoulos, F. N., Zhu, D. L., & Law, C. K. (1990). Experimental and numerical determination of laminar flame speeds Mixtures of C2-hydrocarbons with oxygen and nitrogen. Symposium (International) on Combustion, 23, 471–478.<br>MK1980 - Metghalchi, M., & Keck, J. C. (1980). Laminar burning velocity of propane-air mixtures at high temperature and pressure. Combustion and Flame, 38, 143–154.
uq_unit: cm/s
---