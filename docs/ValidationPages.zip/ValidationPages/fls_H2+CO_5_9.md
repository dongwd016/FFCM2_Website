---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_H2+CO_5_9
temp: 300.0
pres: 1.0
phi: 3.0
composition: 27.88% H2-27.88% CO-9.30% O2-34.95% N2
shortname: MST1994, BCG2011, BQJ2007, SYJ2007, SNT2012, PRR2008, NLS2007
datatype: Laminar flame speed
definition: FFCM1FLS
exp_nominal: 157.51
exp_uq: 6.58
trial_nominal: 165.05
trial_uq: 7.72
opt_nominal: 163.84
opt_uq: 2.26
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_H2+CO_5.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_H2+CO_5_9.png
reference: MST1994 - McLean, I. C., Smith, D. B., & Taylor, S. C. (1994). The use of carbon monoxide/hydrogen burning velocities to examine the rate of the CO+OH reaction. Symposium (International) on Combustion, 25, 749–757.<br>BCG2011 - Bouvet, N., Chauveau, C., Gökalp, I., & Halter, F. (2011). Experimental studies of the fundamental flame speeds of syngas (H2/CO)/air mixtures. Proceedings of the Combustion Institute, 33, 913–920.<br>BQJ2007 - Burke, M. P., Qin, X., Ju, Y., & Dryer, F. L. (2007). Measurements of Hydrogen Syngas Flame Speeds at Elevated Pressures. 5th US Combustion Meeting.<br>SYJ2007 - Sun, H., Yang, S. I., Jomaas, G., & Law, C. K. (2007). High-pressure laminar flame speeds and kinetic modeling of carbon monoxide/hydrogen combustion. Proceedings of the Combustion Institute, 31, 439–446.<br>SNT2012 - Singh, D., Nishiie, T., Tanvir, S., & Qiao, L. (2012). An experimental and kinetic study of syngas/air combustion at elevated temperatures and the effect of water addition. Fuel, 94, 448–456.<br>PRR2008 - Prathap, C., Ray, A., & Ravi, M. R. (2008). Investigation of nitrogen dilution effects on the laminar burning velocity and flame stability of syngas fuel at atmospheric condition. Combustion and Flame, 155, 145–160.<br>NLS2007 - Natarajan, J., Lieuwen, T., & Seitzman, J. (2007). Laminar flame speeds of H2/CO mixtures Effect of CO2 dilution, preheat temperature, and pressure. Combustion and Flame, 151, 104–119.
uq_unit: cm/s
---