---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C3H8_5_5
temp: 298.0
pres: 4.0
phi: 1.1
composition: 4.42% C3H8-20.08% O2-75.50% N2
shortname: GBD2016, HMS2008, HAK1998
datatype: Laminar flame speed
definition: OPF
exp_nominal: 29.67
exp_uq: 2.33
trial_nominal: 27.31
trial_uq: 1.1
opt_nominal: 27.36
opt_uq: 0.38
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C3H8_5.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C3H8_5_5.png
reference: GBD2016 - Goswami, M., Bastiaans, R. J. M., De Goey, L. P. H., & Konnov, A. A. (2016). Experimental and modelling study of the effect of elevated pressure on ethane and propane flames. Fuel, 166, 410–418.<br>HMS2008 - Huzayyin, A. S., Moneib, H. A., Shehatta, M. S., & Attia, A. M. A. (2008). Laminar burning velocity and explosion index of LPG--air and propane--air mixtures. Fuel, 87, 39–57.<br>HAK1998 - Hassan, M. I., Aung, K. T., Kwon, O. C., & Faeth, G. M. (1998). Properties of laminar premixed hydrocarbon/air flames at various pressures. Journal of Propulsion and Power, 14, 479–488.
uq_unit: cm/s
---