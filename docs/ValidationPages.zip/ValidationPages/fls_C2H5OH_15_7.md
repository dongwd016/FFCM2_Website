---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C2H5OH_15_7
temp: 423.0
pres: 5.0
phi: 1.15
composition: 7.45% C2H5OH-19.44% O2-73.10% N2
shortname: BHS2013
datatype: Laminar flame speed
definition: OPF
exp_nominal: 44.23
exp_uq: 4.42
trial_nominal: 46.99
trial_uq: 1.92
opt_nominal: 46.92
opt_uq: 0.63
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C2H5OH_15.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C2H5OH_15_7.png
reference: BHS2013 - Broustail, G., Halter, F., Seers, P., Moréac, G., & Mouna\\"im-Rousselle, C. (2013). Experimental determination of laminar burning velocity for butanol/iso-octane and ethanol/iso-octane blends for different initial pressures. Fuel, 106, 310–317.
uq_unit: cm/s
---