---
layout: validation
parent: ValidationPages
nav_exclude: true
title: ign_AC3H4_8_13
temp: 1407.43
pres: 3.5
phi: 1.0
composition: 1.00% AC3H4-4.00% O2-95.00% AR
shortname: CSD1996
datatype: Shock tube ignition delay measurement
definition: max grad pres
exp_nominal: 522.88
exp_uq: 1.32
trial_nominal: 666.44
trial_uq: 1.12
opt_nominal: 598.2
opt_uq: 1.05
unit: $\mu s$
uq_operation: $ \times / \div$
validation_plot: ../../../assets/data/validation/ign_AC3H4_8.png
sens_plot: ../../../assets/data/sensitivity/sens_ign_AC3H4_8_13.png
reference: CSD1996 - Curran, H., Simmie, J. M., Dagaut, P., Voisin, D., & Cathonnet, M. (1996). The ignition and oxidation of allene and propyne Experiments and kinetic modeling. Symposium (International) on Combustion, 26, 613–620.
---