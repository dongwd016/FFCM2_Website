---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_IC4H8_1_2
temp: 298.0
pres: 1.0
phi: 0.8
composition: 2.72% IC4H8-20.44% O2-76.84% N2
shortname: ZLO2016, PVS2016, ZYS2015, K2011
datatype: Laminar flame speed
definition: OPF
exp_nominal: 27.71
exp_uq: 2.18
trial_nominal: 26.28
trial_uq: 1.15
opt_nominal: 26.89
opt_uq: 0.48
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_IC4H8_1.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_IC4H8_1_2.png
reference: ZLO2016 - Zhou, C.-W., Li, Y., O’Connor, E., Somers, K. P., Thion, S., Keesee, C., … Curran, H. J. (2016). A comprehensive experimental and modeling study of isobutene oxidation. Combustion and Flame, 167, 353–379.<br>PVS2016 - Park, O., Veloo, P. S., Sheen, D. A., Tao, Y., Egolfopoulos, F. N., & Wang, H. (2016). Chemical kinetic model uncertainty minimization through laminar flame speed measurements. Combustion and Flame, 172, 136–152.<br>ZYS2015 - Zhao, P., Yuan, W., Sun, H., Li, Y., Kelley, A. P., Zheng, X., & Law, C. K. (2015). Laminar flame speeds, counterflow ignition, and kinetic modeling of the butene isomers. Proceedings of the Combustion Institute, 35, 309–316.<br>K2011 - Kelley, Andrew Patrick. (2011). Dynamics of expanding flames. Princeton University.
uq_unit: cm/s
---