---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C4H6_4_3
temp: 399.0
pres: 1.0
phi: 0.8
composition: 2.97% C4H6-20.39% O2-76.65% N2
shortname: ZLB2018
datatype: Laminar flame speed
definition: OPF
exp_nominal: 60.03
exp_uq: 6.0
trial_nominal: 59.55
trial_uq: 2.24
opt_nominal: 61.43
opt_uq: 0.86
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C4H6_4.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C4H6_4_3.png
reference: ZLB2018 - Zhou, C.-W., Li, Y., Burke, U., Banyon, C., Somers, K. P., Ding, S., … Curran, H. J. (2018). An experimental and chemical kinetic modeling study of 1,3-butadiene combustion {Ignition} delay time and laminar flame speed measurements. Combustion and Flame, 197, 423–438.
uq_unit: cm/s
---