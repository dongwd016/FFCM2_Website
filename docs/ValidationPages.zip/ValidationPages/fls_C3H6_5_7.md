---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C3H6_5_7
temp: 300.0
pres: 5.0
phi: 1.3
composition: 5.72% C3H6-19.81% O2-74.47% N2
shortname: JZZ2005
datatype: Laminar flame speed
definition: OPF
exp_nominal: 22.31
exp_uq: 2.23
trial_nominal: 21.47
trial_uq: 1.42
opt_nominal: 23.22
opt_uq: 0.53
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C3H6_5.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C3H6_5_7.png
reference: JZZ2005 - Jomaas, G., Zheng, X. L., Zhu, D. L., & Law, C. K. (2005). Experimental determination of counterflow ignition temperatures and laminar flame speeds of C2--C3 hydrocarbons at atmospheric and elevated pressures. Proceedings of the Combustion Institute, 30, 193–200.
uq_unit: cm/s
---