---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C3H8_1_3
temp: 298.0
pres: 0.5
phi: 0.8
composition: 3.25% C3H8-20.33% O2-76.42% N2
shortname: HMS2008, HAK1998, EZL1990
datatype: Laminar flame speed
definition: CFF
exp_nominal: 34.76
exp_uq: 3.76
trial_nominal: 33.98
trial_uq: 1.2
opt_nominal: 33.3
opt_uq: 0.55
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C3H8_1.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C3H8_1_3.png
reference: HMS2008 - Huzayyin, A. S., Moneib, H. A., Shehatta, M. S., & Attia, A. M. A. (2008). Laminar burning velocity and explosion index of LPG--air and propane--air mixtures. Fuel, 87, 39–57.<br>HAK1998 - Hassan, M. I., Aung, K. T., Kwon, O. C., & Faeth, G. M. (1998). Properties of laminar premixed hydrocarbon/air flames at various pressures. Journal of Propulsion and Power, 14, 479–488.<br>EZL1990 - Egolfopoulos, F. N., Zhu, D. L., & Law, C. K. (1990). Experimental and numerical determination of laminar flame speeds Mixtures of C2-hydrocarbons with oxygen and nitrogen. Symposium (International) on Combustion, 23, 471–478.
uq_unit: cm/s
---