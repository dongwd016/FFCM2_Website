---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C2H5OH_19_2
temp: 358.0
pres: 2.0
phi: 0.8
composition: 5.31% C2H5OH-19.89% O2-74.80% N2
shortname: BLM2009
datatype: Laminar flame speed
definition: OPF
exp_nominal: 27.05
exp_uq: 2.7
trial_nominal: 32.61
trial_uq: 1.49
opt_nominal: 31.65
opt_uq: 0.45
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C2H5OH_19.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C2H5OH_19_2.png
reference: BLM2009 - Bradley, D., Lawes, M., & Mansour, M. S. (2009). Explosion bomb measurements of ethanol--air laminar gaseous flame characteristics at pressures up to 1.4 MPa. Combustion and Flame, 156, 1462–1470.
uq_unit: cm/s
---