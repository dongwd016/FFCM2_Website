---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_IC4H8_3_2
temp: 298.0
pres: 5.0
phi: 0.8
composition: 2.72% IC4H8-20.44% O2-76.84% N2
shortname: ZYS2015, K2011
datatype: Laminar flame speed
definition: OPF
exp_nominal: 15.3
exp_uq: 2.0
trial_nominal: 15.79
trial_uq: 0.78
opt_nominal: 16.46
opt_uq: 0.28
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_IC4H8_3.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_IC4H8_3_2.png
reference: ZYS2015 - Zhao, P., Yuan, W., Sun, H., Li, Y., Kelley, A. P., Zheng, X., & Law, C. K. (2015). Laminar flame speeds, counterflow ignition, and kinetic modeling of the butene isomers. Proceedings of the Combustion Institute, 35, 309–316.<br>K2011 - Kelley, Andrew Patrick. (2011). Dynamics of expanding flames. Princeton University.
uq_unit: cm/s
---