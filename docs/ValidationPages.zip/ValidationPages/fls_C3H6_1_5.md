---
layout: validation
parent: ValidationPages
nav_exclude: true
title: fls_C3H6_1_5
temp: 298.0
pres: 1.0
phi: 0.8
composition: 3.60% C3H6-20.25% O2-76.15% N2
shortname: PVS2016, BBM2015, SHS2013, JZZ2005, DL1998, GLW1951
datatype: Laminar flame speed
definition: HF
exp_nominal: 31.56
exp_uq: 2.0
trial_nominal: 31.73
trial_uq: 1.45
opt_nominal: 31.43
opt_uq: 0.58
unit: cm/s
uq_operation: $\pm$
validation_plot: ../../../assets/data/validation/fls_C3H6_1.png
sens_plot: ../../../assets/data/sensitivity/sens_fls_C3H6_1_5.png
reference: PVS2016 - Park, O., Veloo, P. S., Sheen, D. A., Tao, Y., Egolfopoulos, F. N., & Wang, H. (2016). Chemical kinetic model uncertainty minimization through laminar flame speed measurements. Combustion and Flame, 172, 136–152.<br>BBM2015 - Burke, S. M., Burke, U., Mc Donagh, R., Mathieu, O., Osorio, I., Keesee, C., … Curran, H. J. (2015). An experimental and modeling study of propene oxidation. Part 2 Ignition delay time and flame speed measurements. Combustion and Flame, 162, 296–314.<br>SHS2013 - Santner, J., Haas, F. M., Shen, X., Ju, Y., & Dryer, F. L. (2013). High Pressure Studies of Propene Combustion.<br>JZZ2005 - Jomaas, G., Zheng, X. L., Zhu, D. L., & Law, C. K. (2005). Experimental determination of counterflow ignition temperatures and laminar flame speeds of C2--C3 hydrocarbons at atmospheric and elevated pressures. Proceedings of the Combustion Institute, 30, 193–200.<br>DL1998 - Davis, S. G., & Law, C. K. (1998). Determination of and Fuel Structure Effects on Laminar Flame Speeds of C1 to C8 Hydrocarbons. Combustion Science and Technology, 140, 427–449.<br>GLW1951 - Gerstein, M., Levine, O., & Wong, E. L. (1951). Flame propagation. II. The determination of fundamental burning velocities of hydrocarbons by a revised tube method. Journal of the American Chemical Society, 73, 418–422.
uq_unit: cm/s
---